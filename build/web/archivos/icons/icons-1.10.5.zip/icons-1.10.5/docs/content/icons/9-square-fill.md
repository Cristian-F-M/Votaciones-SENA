---
title: 9 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---

---
title: Check all
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - done
  - select
---

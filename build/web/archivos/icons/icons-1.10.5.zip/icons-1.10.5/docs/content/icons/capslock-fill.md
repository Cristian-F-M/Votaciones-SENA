---
title: Capslock fill
categories:
  - UI and keyboard
tags:
  - key
---

---
title: Building fill up
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
